import re
roman = input()
if re.search(r"^(I|V|X|L|C|D|M)+$", roman) == None:
    print("False")
elif re.search(r"(IIII|XXXX|CCCC|MMMM|VV|LL|DD)", roman) != None:
    print("False")
else:
    print("True")
